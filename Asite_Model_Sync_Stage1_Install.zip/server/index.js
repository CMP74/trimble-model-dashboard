import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import crypto from "crypto";

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

// ---------------------------------------------------------
// Temporary POC storage
// Later we will replace this with proper session storage.
// ---------------------------------------------------------

const authSessions = new Map();

let trimbleAuth = {
  accessToken: null,
  refreshToken: null,
  expiresAt: null,
  user: null,
};

// ---------------------------------------------------------
// PKCE helpers
// ---------------------------------------------------------

function base64UrlEncode(buffer) {
  return buffer
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=/g, "");
}

function createCodeVerifier() {
  return base64UrlEncode(crypto.randomBytes(64));
}

function createCodeChallenge(verifier) {
  return base64UrlEncode(
    crypto.createHash("sha256").update(verifier).digest()
  );
}

// ---------------------------------------------------------
// Basic test routes
// ---------------------------------------------------------

app.get("/", (req, res) => {
  res.send("Backend is working");
});

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    message: "Trimble dashboard backend is running",
  });
});

// ---------------------------------------------------------
// 1. Start Trimble login
// ---------------------------------------------------------

app.get("/api/auth/login", (req, res) => {
  const codeVerifier = createCodeVerifier();
  const codeChallenge = createCodeChallenge(codeVerifier);
  const state = base64UrlEncode(crypto.randomBytes(32));

  authSessions.set(state, {
    codeVerifier,
    createdAt: Date.now(),
  });

  const params = new URLSearchParams({
    client_id: process.env.TRIMBLE_CLIENT_ID,
    response_type: "code",
    scope: `openid ${process.env.TRIMBLE_APPLICATION_NAME}`,
    redirect_uri: process.env.TRIMBLE_CALLBACK_URL,
    state,
    code_challenge: codeChallenge,
    code_challenge_method: "S256",
  });

  const authorizationUrl =
    `https://id.trimble.com/oauth/authorize?${params.toString()}`;

  res.json({
    authorizationUrl,
  });
});

// ---------------------------------------------------------
// 2. Exchange authorization code for Trimble token
// ---------------------------------------------------------

app.post("/api/auth/callback", async (req, res) => {
  try {
    const { code, state } = req.body;

    if (!code || !state) {
      return res.status(400).json({
        error: "Missing authorization code or state",
      });
    }

    const session = authSessions.get(state);

    if (!session) {
      return res.status(400).json({
        error: "Invalid or expired authentication state",
      });
    }

    const tokenResponse = await fetch(
      "https://id.trimble.com/oauth/token",
      {
        method: "POST",

        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },

        body: new URLSearchParams({
          grant_type: "authorization_code",
          client_id: process.env.TRIMBLE_CLIENT_ID,
          code,
          redirect_uri: process.env.TRIMBLE_CALLBACK_URL,
          code_verifier: session.codeVerifier,
        }),
      }
    );

    const tokenData = await tokenResponse.json();

    if (!tokenResponse.ok) {
      console.error("Trimble token error:", tokenData);

      return res.status(tokenResponse.status).json({
        error: "Trimble token exchange failed",
        details: tokenData,
      });
    }

    authSessions.delete(state);

    trimbleAuth.accessToken = tokenData.access_token;
    trimbleAuth.refreshToken = tokenData.refresh_token || null;

    trimbleAuth.expiresAt = tokenData.expires_in
      ? Date.now() + tokenData.expires_in * 1000
      : null;

    console.log("Trimble access token received");

    // -----------------------------------------------------
    // Test the token against Trimble Connect
    // -----------------------------------------------------

    const userResponse = await fetch(
      "https://app.connect.trimble.com/tc/api/2.0/users/me",
      {
        headers: {
          Authorization: `Bearer ${trimbleAuth.accessToken}`,
        },
      }
    );

    const userData = await userResponse.json();

    if (!userResponse.ok) {
      console.error("Trimble user request failed:", userData);

      return res.status(userResponse.status).json({
        error: "Authenticated, but could not retrieve Trimble user",
        details: userData,
      });
    }

    trimbleAuth.user = userData;

    console.log("Trimble user retrieved successfully");

    res.json({
      success: true,
      user: userData,
    });
  } catch (error) {
    console.error("Authentication callback error:", error);

    res.status(500).json({
      error: "Authentication callback failed",
    });
  }
});

// ---------------------------------------------------------
// 3. Authentication status
// ---------------------------------------------------------

app.get("/api/auth/status", (req, res) => {
  res.json({
    authenticated: Boolean(trimbleAuth.accessToken),
    user: trimbleAuth.user,
  });
  
 app.get("/api/auth/viewer-token", (req, res) => {
  res.set("Cache-Control", "no-store");

  if (!trimbleAuth.accessToken) {
    return res.status(401).json({
      error: "Not connected to Trimble",
    });
  }

  res.json({
    accessToken: trimbleAuth.accessToken,
  });
}); 

  if (
    !trimbleAuth.accessToken ||
    (trimbleAuth.expiresAt && Date.now() >= trimbleAuth.expiresAt)
  ) {
    return res.status(401).json({
      error: "Trimble session missing or expired",
    });
  }

  res.set("Cache-Control", "no-store");

  res.json({
    accessToken: trimbleAuth.accessToken,
  });
});


// ---------------------------------------------------------
// Mock FieldView API
// ---------------------------------------------------------

const mockFieldViewRecords = [
  {
    id: "ITP-001",
    type: "ITP",
    title: "Structural concrete inspection",
    status: "Passed",
    date: "24 Sep 2026",
    modelGuid: "demo-wall-001",
  },
  {
    id: "NCR-014",
    type: "NCR",
    title: "Concrete finish NCR",
    status: "Open",
    date: "25 Sep 2026",
    modelGuid: "demo-wall-001",
  },
  {
    id: "ITP-002",
    type: "Inspection",
    title: "Structural element inspection",
    status: "Closed",
    date: "26 Sep 2026",
    modelGuid: "demo-beam-001",
  },
];

app.get("/api/fieldview/records", (req, res) => {
  const { modelGuid } = req.query;

  // If a model GUID is supplied, return records linked
  // to that particular BIM object.
  if (modelGuid) {
    const records = mockFieldViewRecords.filter(
      (record) => record.modelGuid === modelGuid
    );

    return res.json({
      source: "mock-fieldview",
      count: records.length,
      records,
    });
  }

  // Otherwise return all FieldView records.
  res.json({
    source: "mock-fieldview",
    count: mockFieldViewRecords.length,
    records: mockFieldViewRecords,
  });
});

// ---------------------------------------------------------
// Mock Trimble model API
// ---------------------------------------------------------

const mockModels = [
  {
    id: "model-001",
    name: "Building-Structural.ifc",
    discipline: "Structural",
    loaded: true,
    source: "Trimble Connect",
  },
  {
    id: "model-002",
    name: "Architecture.ifc",
    discipline: "Architectural",
    loaded: false,
    source: "Trimble Connect",
  },
  {
    id: "model-003",
    name: "MEP.ifc",
    discipline: "MEP",
    loaded: false,
    source: "Trimble Connect",
  },
];

app.get("/api/models", async (req, res) => {
  if (!trimbleAuth.accessToken) {
    return res.status(401).json({
      error: "Connect to Trimble first",
    });
  }

  try {
    const projectId = "7nAFSwau0CI";

    const response = await fetch(
      `https://app22.connect.trimble.com/tc/api/2.0/folders/KVqla3gS1XY/items`,
      {
        headers: {
          Authorization: `Bearer ${trimbleAuth.accessToken}`,
          Accept: "application/json",
        },
      }
    );

    if (!response.ok) {
      const errorText = await response.text();

      console.error(
        "Trimble models API failed:",
        response.status,
        errorText
      );

      return res.status(502).json({
        error: "Could not retrieve Trimble Connect models",
        trimbleStatus: response.status,
      });
    }

    const data = await response.json();

    console.log(
  "Trimble models response:",
  JSON.stringify(data, null, 2).slice(0, 3000)
);

    const rawModels = Array.isArray(data)
      ? data
      : Array.isArray(data.models)
        ? data.models
        : Array.isArray(data.items)
          ? data.items
          : [];

    const models = rawModels.map((model) => ({
      id: String(model.id),
      name: model.name || "Unnamed model",
      discipline: "Unclassified",
      loaded: false,
      source: "Trimble Connect",
    }));

    return res.json({
      source: "trimble-connect",
      count: models.length,
      models,
    });
  } catch (error) {
    console.error("Trimble models request failed:", error);

    return res.status(500).json({
      error: "Could not retrieve Trimble Connect models",
    });
  }
});

// ---------------------------------------------------------
// Mock BIM object data
// ---------------------------------------------------------

const mockModelObjects = [
  {
    guid: "demo-wall-001",
    modelId: "model-001",
    type: "IfcWall",
    name: "External Concrete Wall",
    level: "Ground Floor",
    material: "Concrete",
    discipline: "Structural",
  },
  {
    guid: "demo-beam-001",
    modelId: "model-001",
    type: "IfcBeam",
    name: "Primary Structural Beam",
    level: "Level 01",
    material: "Steel",
    discipline: "Structural",
  },
];

app.get("/api/model-objects", (req, res) => {
  res.json({
    source: "mock-model-data",
    count: mockModelObjects.length,
    objects: mockModelObjects,
  });
});

app.get("/api/model-objects/:guid", (req, res) => {
  const object = mockModelObjects.find(
    (item) => item.guid === req.params.guid
  );

  if (!object) {
    return res.status(404).json({
      error: "Model object not found",
    });
  }

  res.json({
    source: "mock-model-data",
    object,
  });
});


// ---------------------------------------------------------
// Mock Asite model data
// ---------------------------------------------------------

const mockAsiteModels = [
  {
    id: "asite-model-001",
    name: "Structural_Model_Rev_P03.ifc",
    revision: "P03",
    discipline: "Structural",
    status: "Published",
    size: "48.2 MB",
    modifiedDate: "27 Sep 2026",
    source: "Asite",
  },
  {
    id: "asite-model-002",
    name: "Architectural_Model_Rev_P05.ifc",
    revision: "P05",
    discipline: "Architectural",
    status: "Published",
    size: "62.7 MB",
    modifiedDate: "26 Sep 2026",
    source: "Asite",
  },
  {
    id: "asite-model-003",
    name: "MEP_Coordination_Rev_P02.ifc",
    revision: "P02",
    discipline: "MEP",
    status: "Published",
    size: "37.4 MB",
    modifiedDate: "25 Sep 2026",
    source: "Asite",
  },
];

app.get("/api/asite/models", (req, res) => {
  res.json({
    source: "mock-asite",
    count: mockAsiteModels.length,
    models: mockAsiteModels,
  });
});

// Asite OAuth integration readiness only. No browser-held Asite credentials,
// session-cookie reuse, or unauthenticated document proxying.
app.get("/api/asite/connection", (_req, res) => {
  res.set("Cache-Control", "no-store");
  res.json({
    configured: false,
    message: "Asite Microsoft SSO API access requires an approved OAuth client registration. Live document listing is not yet enabled.",
  });
});

// ---------------------------------------------------------
// Start server
// ---------------------------------------------------------

const PORT = 3000;

app.get("/api/auth/viewer-token", (req, res) => {
  res.set("Cache-Control", "no-store");

  if (!trimbleAuth.accessToken) {
    return res.status(401).json({
      error: "Not connected to Trimble",
    });
  }

  return res.json({
    accessToken: trimbleAuth.accessToken,
  });
});

app.listen(PORT, () => {
  console.log(`Backend running on http://localhost:${PORT}`);
});