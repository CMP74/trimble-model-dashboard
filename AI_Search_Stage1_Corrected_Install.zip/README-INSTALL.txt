Extract this ZIP from the Vite project root (the directory containing package.json).
Run: unzip -o AI_Search_Stage1_Corrected_Install.zip
Then: npm run build
Existing public/fieldview CSV files remain unchanged.
