Adds a Trimble Connect PDF list below Models on the 3D Dashboard. Lists name and revision from existing GET /api/documents. Refresh button reloads the list. AI Search button opens existing PDF indexing/search tab. No backend changes. Existing Excel export and all other tabs preserved.

Install from project root:
  cp src/App.tsx src/App.tsx.before-document-list
  unzip -o Trimble_Dashboard_PDF_Document_List.zip -d .
  npm run build

Keep backend running to preserve the in-memory PDF index.
